#!/bin/sh
javabin=$JAVA_HOME/bin/java
type $javabin > /dev/null 2>$1 || { echo >&2 "Please set JAVA_HOME!";exit 1;}

hasnohup=1
type nohup > /dev/null 2>&1 || { hasnohup=0; }

if [ $hasnohup -eq 1 ]; then
	nohup $javabin -jar jlu-drcom-java-1.0.1.jar > /dev/null 2>&1 &;
else
	echo -e "There is no [nohup] commond,
	Please DO NOT close the terminal/shell while the app is running,
	OR the app will be killed."
	$javabin -jar jlu-drcom-java-1.0.2.jar > /dev/null &
fi
